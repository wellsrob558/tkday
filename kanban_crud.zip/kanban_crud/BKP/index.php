<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Planejamento de Tarefas</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;600&display=swap" rel="stylesheet">
    <script src="script.js" defer></script>
    <style>
        body {
            font-family: 'Barlow', sans-serif; /* Aplicar a fonte Barlow */
            background-color: #f5f5f5;
            color: #333;
            text-align: center;
            margin: 0;
            padding: 20px;
        }

        h1 {
            margin-bottom: 20px;
        }

        form {
            margin-bottom: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        input[type="text"],
        textarea,
        select {
            width: 100%;
            max-width: 300px; /* Ajustar a largura máxima */
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            background-color: #28a745; /* Verde */
            color: white;
            padding: 10px 15px; /* Ajustar o preenchimento */
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin: 5px; /* Adicionar margem entre os botões */
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #218838; /* Verde escuro ao passar o mouse */
        }

        .kanban-board {
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
            flex-wrap: wrap; /* Para tornar responsivo */
        }

        .kanban-column {
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            width: 30%; /* Ajustar a largura das colunas */
            margin: 5px; /* Margem entre colunas */
        }

        .task {
            background-color: #f8d7da; /* Fundo da tarefa */
            border-radius: 5px;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #f5c6cb; /* Borda da tarefa */
        }

        /* Responsividade */
        @media (max-width: 768px) {
            .kanban-column {
                width: 100%; /* Colunas se empilham em telas menores */
            }
        }
    </style>
</head>
<body>
    <h1>Planejamento de Tarefas - Dôminos</h1>

    <!-- Formulário de criação de nova tarefa -->
    <form id="taskForm">
        <input type="text" id="title" placeholder="Título da tarefa" required>
        <textarea id="desc" placeholder="Descrição da tarefa" required></textarea>
        <button type="submit">Criar Tarefa</button>
    </form>

    <div class="kanban-board">
        <div class="kanban-column" id="to-do-tasks">
            <h2>A Fazer</h2>
            <div class="task-list" id="to-do-list"></div>
        </div>
        <div class="kanban-column" id="in-progress-tasks">
            <h2>Em Progresso</h2>
            <div class="task-list" id="in-progress-list"></div>
        </div>
        <div class="kanban-column" id="done-tasks">
            <h2>Concluído</h2>
            <div class="task-list" id="done-list"></div>
        </div>
    </div>

    <script>
        // Função para criar uma nova tarefa (inserção)
        document.getElementById('taskForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const title = document.getElementById('title').value;
            const desc = document.getElementById('desc').value;

            fetch('create_task.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title, desc })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Tarefa criada com sucesso!');
                    addTaskToColumn(data.task); // Adiciona a nova tarefa na coluna "A Fazer"
                } else {
                    alert('Erro ao criar tarefa: ' + data.error);
                }
            });
        });

        // Função para adicionar uma tarefa na coluna correspondente
        function addTaskToColumn(task) {
            const taskDiv = document.createElement('div');
            taskDiv.classList.add('task');
            taskDiv.setAttribute('data-id', task.id);
            taskDiv.innerHTML = `
                <h3>${task.titulo}</h3>
                <p>${task.descricao}</p>
                <select style="width: calc(100%);" onchange="updateTaskStatus(${task.id}, this.value)"> <!-- Adicionando onchange -->
                    <option value='A Fazer' ${task.status === 'A Fazer' ? 'selected' : ''}>A Fazer</option>
                    <option value='Em Progresso' ${task.status === 'Em Progresso' ? 'selected' : ''}>Em Progresso</option>
                    <option value='Concluído' ${task.status === 'Concluído' ? 'selected' : ''}>Concluído</option>
                </select>
                <div style="display: flex; justify-content: center; margin-top: 5px;">
                    <button onclick='updateTask(${task.id}, "${task.titulo}", "${task.descricao}")'>Atualizar</button>
                    <button onclick='deleteTask(${task.id})'>Excluir</button>
                </div>
            `;
            document.getElementById('to-do-list').appendChild(taskDiv); // Adiciona a tarefa na coluna "A Fazer"
            moveTaskToColumn(task.id, task.status); // Move a tarefa para a coluna correspondente
        }

        // Função para atualizar uma tarefa
        function updateTask(id, currentTitle, currentDesc) {
            const newTitle = prompt("Atualizar título:", currentTitle);
            const newDesc = prompt("Atualizar descrição:", currentDesc);

            if (newTitle && newDesc) {
                fetch('update_task.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id, title: newTitle, desc: newDesc })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Tarefa atualizada com sucesso!');
                        location.reload(); // Recarregar a página para atualizar o Kanban
                    } else {
                        alert('Erro ao atualizar tarefa: ' + data.error);
                    }
                });
            }
        }

        // Função para atualizar o status da tarefa
        function updateTaskStatus(id, status) {
            fetch('update_task.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id, status })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Status da tarefa atualizado com sucesso!');
                    moveTaskToColumn(id, status); // Move a tarefa para a coluna correspondente
                } else {
                    alert('Erro ao atualizar status: ' + data.error);
                }
            });
        }

        // Função para mover a tarefa para a coluna correta
        function moveTaskToColumn(id, status) {
            const taskDiv = document.querySelector(`.task[data-id='${id}']`);
            const fromColumn = taskDiv.parentElement.id;
            const toColumn = status === 'A Fazer' ? 'to-do-list' : status === 'Em Progresso' ? 'in-progress-list' : 'done-list';

            // Remove a tarefa da coluna antiga
            taskDiv.parentElement.removeChild(taskDiv);

            // Adiciona a tarefa na nova coluna
            document.getElementById(toColumn).appendChild(taskDiv);
        }

        // Função para excluir uma tarefa
        function deleteTask(id) {
            if (confirm("Tem certeza que deseja excluir esta tarefa?")) {
                fetch('delete_task.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Tarefa excluída com sucesso!');
                        location.reload(); // Recarregar a página para atualizar o Kanban
                    } else {
                        alert('Erro ao excluir tarefa: ' + data.error);
                    }
                });
            }
        }
    </script>

    <?php
    // Conectar ao banco de dados
    $conn = new mysqli('localhost', 'root', 'admin', 'kanban_db');

    // Verificar conexão
    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }

    // Consultar tarefas
    $result = $conn->query("SELECT * FROM tb_tarefas");

    // Inicializar array para as tarefas
    $tasks = [];
    while ($row = $result->fetch_assoc()) {
        $tasks[] = $row;
    }

    // Fechar conexão
    $conn->close();
    ?>

    <script>
        // Preencher o Kanban com tarefas existentes ao carregar a página
        document.addEventListener("DOMContentLoaded", function() {
            const tasks = <?php echo json_encode($tasks); ?>; // Receber tarefas do PHP
            tasks.forEach(task => {
                addTaskToColumn(task); // Adiciona cada tarefa na coluna correta
            });
        });
    </script>
</body>
</html>
