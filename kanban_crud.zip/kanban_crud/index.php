<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planejamento de Tarefas</title>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;600&display=swap" rel="stylesheet">
    <script src="script.js" defer></script>
    <style>
        body {
            font-family: 'Barlow', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
        }

        input, textarea {
            width: 300px;
            padding: 10px;
            margin: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            padding: 10px 20px;
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #4cae4c;
        }

        .delete-button {
            background-color: #d9534f; /* Cor de fundo vermelha */
            color: white; /* Texto em branco */
            border: none; /* Sem borda */
            border-radius: 5px; /* Cantos arredondados */
         
            cursor: pointer; /* Cursor de pointer */
            transition: background-color 0.3s; /* Transição suave */
        }

        .delete-button:hover {
            background-color: #c9302c; /* Cor mais escura ao passar o mouse */
        }

        .kanban-board {
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
        }

        .kanban-column {
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 300px;
            padding: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .kanban-column h2 {
            text-align: center;
            color: #333;
        }

        .task-list {
            min-height: 150px; /* Define uma altura mínima */
            padding: 5px;
            display: flex;
            flex-direction: column;
            gap: 10px; /* Espaçamento entre as tarefas */
        }

        .task {
            background-color: #e9ecef;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
            transition: background-color 0.3s;
            cursor: move; /* Mudança de cursor ao passar por cima da tarefa */
        }

        .task:hover {
            background-color: #d3d3d3;
        }
    </style>
</head>
<body>
    <h1>Planejamento de Tarefas - Dôminos</h1>

    <form id="taskForm">
        <input type="text" id="title" placeholder="Título da tarefa" required>
        <textarea id="desc" placeholder="Descrição da tarefa" required></textarea>
        <button type="submit">Criar Tarefa</button>
    </form>

    <div class="kanban-board">
        <div class="kanban-column" id="to-do-tasks" ondrop="drop(event)" ondragover="allowDrop(event)">
            <h2>A Fazer</h2>
            <div class="task-list" id="to-do-list"></div>
        </div>
        <div class="kanban-column" id="in-progress-tasks" ondrop="drop(event)" ondragover="allowDrop(event)">
            <h2>Em Progresso</h2>
            <div class="task-list" id="in-progress-list"></div>
        </div>
        <div class="kanban-column" id="done-tasks" ondrop="drop(event)" ondragover="allowDrop(event)">
            <h2>Concluído</h2>
            <div class="task-list" id="done-list"></div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            fetch('read_tasks.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        data.tasks.forEach(task => {
                            addTaskToColumn(task);
                        });
                    } else {
                        alert('Erro ao carregar tarefas: ' + data.error);
                    }
                })
                .catch(error => console.error('Erro ao buscar tarefas:', error));
        });

        document.getElementById('taskForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const title = document.getElementById('title').value;
            const desc = document.getElementById('desc').value;

            fetch('create_task.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title, desc })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    alert('Tarefa criada com sucesso!');
                    addTaskToColumn(data.task); // Adiciona a nova tarefa na coluna "A Fazer"
                } else {
                    alert('Erro ao criar tarefa: ' + data.error);
                }
            })
            .catch(error => {
                console.error('Houve um problema com a requisição Fetch:', error);
            });
        });

        // Função para adicionar uma tarefa na coluna correta com base no status
        function addTaskToColumn(task) {
            const taskDiv = document.createElement('div');
            taskDiv.className = 'task';
            taskDiv.draggable = true;
            taskDiv.id = task.id;
            taskDiv.ondragstart = function(event) { event.dataTransfer.setData('text/plain', task.id); };
            taskDiv.innerHTML = `
                <h3>${task.title}</h3>
                <p>${task.desc}</p>
                <button onclick="editTask(${task.id}, '${task.title}', '${task.desc}')">Editar</button>
                <button class="delete-button" onclick="deleteTask(${task.id})">Excluir</button>
            `;

            // Adiciona a tarefa à coluna correta com base no status
            const taskListId = {
                'A Fazer': 'to-do-list',
                'Em Progresso': 'in-progress-list',
                'Concluído': 'done-list'
            }[task.status]; // Obtém o ID da lista correspondente ao status

            if (taskListId) {
                document.getElementById(taskListId).appendChild(taskDiv);
            } else {
                console.error('Status desconhecido:', task.status);
            }

            taskDiv.ondragend = () => {
                taskDiv.classList.remove('dragging');
            };
        }

        function allowDrop(event) {
            event.preventDefault();
        }

        function drop(event) {
            const taskId = event.dataTransfer.getData('text/plain');
            const targetColumn = event.currentTarget.id;

            const taskDiv = document.getElementById(taskId);
            const newStatus = {
                'to-do-tasks': 'A Fazer',
                'in-progress-tasks': 'Em Progresso',
                'done-tasks': 'Concluído'
            }[targetColumn]; // Mapeia o ID da coluna para o novo status

            // Atualiza o status da tarefa no banco de dados
            fetch('update_task_status.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: taskId, status: newStatus })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Atualiza a interface
                    const targetList = document.getElementById(targetColumn).querySelector('.task-list');
                    targetList.appendChild(taskDiv);
                    alert('Status da tarefa atualizado para: ' + newStatus);
                } else {
                    alert('Erro ao atualizar status da tarefa: ' + data.error);
                }
            })
            .catch(error => console.error('Erro ao atualizar tarefa:', error));
        }

        function editTask(taskId, title, desc) {
            const newTitle = prompt('Editar título:', title);
            const newDesc = prompt('Editar descrição:', desc);
            if (newTitle !== null && newDesc !== null) {
                fetch('edit_task.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: taskId, title: newTitle, desc: newDesc })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Atualiza a tarefa na interface
                        const taskDiv = document.getElementById(taskId);
                        taskDiv.querySelector('h3').innerText = newTitle;
                        taskDiv.querySelector('p').innerText = newDesc;
                        alert('Tarefa editada com sucesso!');
                    } else {
                        alert('Erro ao editar a tarefa: ' + data.error);
                    }
                })
                .catch(error => console.error('Erro ao editar a tarefa:', error));
            }
        }

        function deleteTask(taskId) {
            if (confirm('Tem certeza que deseja excluir esta tarefa?')) {
                fetch('delete_task.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: taskId })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById(taskId).remove();
                        alert('Tarefa excluída com sucesso!');
                    } else {
                        alert('Erro ao excluir a tarefa: ' + data.error);
                    }
                })
                .catch(error => console.error('Erro ao excluir a tarefa:', error));
            }
        }
    </script>
</body>
</html>
