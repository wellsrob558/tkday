<?php

$conn = new mysqli('localhost', 'root', 'admin', 'kanban_db');

// Verificar conexão
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Conexão falhou: ' . $conn->connect_error]);
    exit;
}

// Receber os dados JSON
$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'] ?? null; // ID da tarefa
$status = $data['status'] ?? null; // Novo status

if ($id && $status) {
    // Preparar a consulta
    $stmt = $conn->prepare("UPDATE tb_tarefas SET status=? WHERE id=?");
    $stmt->bind_param('si', $status, $id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'id' => $id]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'ID ou status da tarefa não fornecidos.']);
}

$stmt->close();
$conn->close();
?>
