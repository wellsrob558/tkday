<?php
header('Content-Type: application/json');

// Cria a conexão com o banco de dados
$conn = new mysqli('localhost', 'root', 'admin', 'kanban_db');

// Verifica se houve erro na conexão
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Erro na conexão: ' . $conn->connect_error]);
    exit();
}

// Consulta para buscar todas as tarefas
$query = "SELECT id, titulo, descricao, status FROM tb_tarefas"; 
$result = $conn->query($query); // Executa a consulta

if (!$result) { // Verifica se a consulta falhou
    echo json_encode(['success' => false, 'error' => 'Erro na consulta: ' . $conn->error]); // Retorna mensagem de erro
    exit(); // Encerra a execução
}

// Verifica se há tarefas retornadas
if ($result->num_rows === 0) {
    echo json_encode(['success' => true, 'tasks' => []]); // Retorna um array vazio se não houver tarefas
    exit();
}

$tasks = []; // Array para armazenar as tarefas
while ($row = $result->fetch_assoc()) { // Loop para buscar cada tarefa
    $tasks[] = [ // Adiciona cada tarefa ao array
        'id' => $row['id'],
        'title' => $row['titulo'], // Usando o nome correto da coluna
        'desc' => $row['descricao'], // Usando o nome correto da coluna
        'status' => $row['status'] // Inclui o status
    ];
}

// Retorna as tarefas em formato JSON
echo json_encode(['success' => true, 'tasks' => $tasks]); 
$conn->close(); // Fecha a conexão com o banco de dados
?>
