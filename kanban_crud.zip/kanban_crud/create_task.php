<?php
// Conectar ao banco de dados
$conn = new mysqli('localhost', 'root', 'admin', 'kanban_db');

// Definir o cabeçalho como JSON
header('Content-Type: application/json');

// Verificar conexão
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'error' => 'Conexão falhou: ' . $conn->connect_error]));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $title = $data['title'];
    $desc = $data['desc'];

    if (empty($title)) {
        echo json_encode(['success' => false, 'error' => 'Título da tarefa está vazio.']);
    } else {
        // Usando prepared statements para evitar injeção de SQL
        $stmt = $conn->prepare("INSERT INTO tb_tarefas (titulo, descricao, status) VALUES (?, ?, 'A Fazer')");
        $stmt->bind_param("ss", $title, $desc);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'task' => ['id' => $stmt->insert_id, 'title' => $title, 'desc' => $desc, 'status' => 'A Fazer']]); // Retorna a nova tarefa criada
        } else {
            echo json_encode(['success' => false, 'error' => $stmt->error]);
        }

        $stmt->close(); // Fechar o statement
    }
}

// Fechar a conexão
$conn->close();
?>
