<?php
// delete_task.php
header('Content-Type: application/json');

$conn = new mysqli('localhost', 'root', 'admin', 'kanban_db');

// Verificar conexão
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Conexão falhou: ' . $conn->connect_error]);
    exit;
}

// Receber os dados JSON
$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'] ?? null; // ID da tarefa a ser excluída

if ($id === null) {
    echo json_encode(['success' => false, 'error' => 'ID da tarefa não foi fornecido.']);
    exit;
}

// Preparar a consulta
$stmt = $conn->prepare("DELETE FROM tb_tarefas WHERE id=?");
$stmt->bind_param('i', $id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Nenhuma tarefa encontrada com esse ID.']);
    }
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

$stmt->close();
$conn->close();
?>
