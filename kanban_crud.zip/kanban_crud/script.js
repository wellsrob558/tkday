// Função para carregar as tarefas
function loadTasks() {
    fetch('read_tasks.php')
    .then(response => response.json())
    .then(data => {
        // Limpar as colunas antes de adicionar novas tarefas
        document.querySelectorAll('.column').forEach(column => {
            column.innerHTML = ''; // Limpa a coluna para não duplicar as tarefas
        });
        
        // Adiciona cada tarefa na coluna correspondente
        data.forEach(task => {
            const taskElement = createTaskElement(task.id, task.titulo, task.descricao);
            const column = document.querySelector(`.column[data-status="${task.status}"]`);
            if (column) {
                column.appendChild(taskElement);
            }
        });
    })
    .catch(error => {
        console.error('Erro ao carregar as tarefas:', error);
    });
}

// Função para criar o elemento de tarefa
function createTaskElement(id, title, desc) {
    const taskElement = document.createElement('div');
    taskElement.className = 'task';
    taskElement.draggable = true;
    taskElement.dataset.id = id;
    taskElement.innerHTML = `<h3>${title}</h3><p>${desc}</p><button onclick="deleteTask(${id})">Excluir</button>`;
    
    taskElement.addEventListener('dragstart', dragStart);
    taskElement.addEventListener('dragend', dragEnd);
    
    return taskElement;
}

// Função para excluir uma tarefa
function deleteTask(id) {
    if (confirm('Deseja realmente excluir esta tarefa?')) {
        fetch('delete_task.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadTasks(); // Recarrega as tarefas após a exclusão
            }
        });
    }
}

// Funções de drag-and-drop
function dragStart(event) {
    event.dataTransfer.setData('text/plain', event.target.dataset.id);
}

function dragEnd(event) {
    const status = event.target.closest('.column').dataset.status; // Corrigido para pegar o status da coluna
    const id = event.target.dataset.id;
    updateTaskStatus(id, status);
}

// Atualiza o status da tarefa
function updateTaskStatus(id, status) {
    fetch('update_task.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log('Status atualizado com sucesso');
            loadTasks(); // Recarrega as tarefas para atualizar a visualização
        }
    });
}

// Inicializar o Kanban
loadTasks();

// Função para arrastar as tarefas entre as colunas
document.querySelectorAll('.column').forEach(column => {
    column.addEventListener('dragover', event => {
        event.preventDefault();
    });

    column.addEventListener('drop', event => {
        const id = event.dataTransfer.getData('text');
        const taskElement = document.querySelector(`[data-id='${id}']`);
        event.target.appendChild(taskElement);
        const newStatus = event.target.dataset.status; // Atualiza o status da tarefa
        updateTaskStatus(id, newStatus);
    });
});
