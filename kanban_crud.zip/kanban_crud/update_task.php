<?php
header('Content-Type: application/json');

// Cria a conexão com o banco de dados
$conn = new mysqli('localhost', 'root', 'admin', 'kanban_db');

// Verifica se houve erro na conexão
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Erro na conexão: ' . $conn->connect_error]);
    exit();
}

// Receber os dados JSON
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['id']) || !isset($data['status'])) {
    echo json_encode(['success' => false, 'error' => 'ID da tarefa ou status não foi fornecido.']);
    exit;
}

$id = $data['id'];
$status = $data['status']; // Certifique-se de que o status está sendo passado corretamente

// Preparar a consulta para atualizar apenas o status
$stmt = $conn->prepare("UPDATE tb_tarefas SET status=? WHERE id=?");
$stmt->bind_param('si', $status, $id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'id' => $id, 'message' => 'Tarefa atualizada com sucesso!']);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

$stmt->close();
$conn->close();
?>
